import time
from redis.cluster import RedisCluster, ClusterNode

SID = "12403030211"
C = 1
S = 11
N = 1000 + 100 * C + S  # 1111
Q = 100                 # 每批最多 100 条

# 连接 Redis 集群
r = RedisCluster(
    startup_nodes=[ClusterNode("127.0.0.1", 30211)],
    decode_responses=True
)

print(f"=== 参数信息：SID={SID}, N={N}, Q={Q} ===")

# ==================== 1. 方案甲：逐条写入 ====================
print("\n>>> 开始执行【方案甲：逐条写入】...")
# 先清理方案甲的历史键
del_pipe = r.pipeline(transaction=False)
for i in range(1, N + 1):
    del_pipe.delete(f"exam:{SID}:seq:{i}")
del_pipe.execute()

start_time_seq = time.perf_counter()

# 严格逐条发送，收到响应后再发送下一条
for i in range(1, N + 1):
    key = f"exam:{SID}:seq:{i}"
    val = f"value-{SID}-{i}"
    r.set(key, val)

end_time_seq = time.perf_counter()
cost_time_seq = end_time_seq - start_time_seq
print(f"【方案甲完成】共逐条写入 {N} 条，耗时: {cost_time_seq:.4f} 秒")


# ==================== 2. 方案乙：普通 Pipeline 分批写入 ====================
print("\n>>> 开始执行【方案乙：Pipeline 分批写入】...")
# 先清理方案乙的历史键
del_pipe = r.pipeline(transaction=False)
for i in range(1, N + 1):
    del_pipe.delete(f"exam:{SID}:pipe:{i}")
del_pipe.execute()

start_time_pipe = time.perf_counter()

# 创建非事务型 Pipeline（显式设置 transaction=False）
pipe = r.pipeline(transaction=False)
batch_count = 0
current_batch_size = 0

for i in range(1, N + 1):
    key = f"exam:{SID}:pipe:{i}"
    val = f"value-{SID}-{i}"
    pipe.set(key, val)
    current_batch_size += 1

    # 达到每批上限 Q=100，或者已经达到总数 N（处理最后不足 100 的批次）
    if current_batch_size == Q or i == N:
        results = pipe.execute()  # 一批执行并取得全部结果
        batch_count += 1
        # print(f"  批次 {batch_count}: 提交 {current_batch_size} 条完成")
        current_batch_size = 0

end_time_pipe = time.perf_counter()
cost_time_pipe = end_time_pipe - start_time_pipe
print(f"【方案乙完成】共写入 {N} 条（分 {batch_count} 批，最后一批 {N % Q} 条），耗时: {cost_time_pipe:.4f} 秒")

# ==================== 3. 初步核验与性能对比 ====================
print("\n================ 性能初步对比 ================")
print(f"方案甲（逐条写入）耗时: {cost_time_seq:.4f} 秒")
print(f"方案乙（Pipeline写入）耗时: {cost_time_pipe:.4f} 秒")
speedup = cost_time_seq / cost_time_pipe if cost_time_pipe > 0 else 0
print(f"Pipeline 相比逐条写入提速约为: {speedup:.2f} 倍")