# -*- coding: utf-8 -*-
"""
第四题 第2小题：计时与结果输出
"""
import time
import math
from redis.cluster import RedisCluster, ClusterNode

SID = "12403030211"
C = 1
S = 11
N = 1000 + 100 * C + S  # 1111
Q = 100                 # 每批最多 100

# 计算理论批次与最后一批数量
total_batches = math.ceil(N / Q)      # 12 批
last_batch_size = N % Q if N % Q != 0 else Q  # 11 条

# 连接 Redis 集群
r = RedisCluster(
    startup_nodes=[ClusterNode("127.0.0.1", 30211)],
    decode_responses=True
)

# 0. 预先清空旧数据
del_pipe = r.pipeline(transaction=False)
for i in range(1, N + 1):
    del_pipe.delete(f"exam:{SID}:seq:{i}")
    del_pipe.delete(f"exam:{SID}:pipe:{i}")
del_pipe.execute()

# ==================== 1. 方案甲：逐条写入计时 ====================
# 计时包括：命令构造、发送和回复接收
start_seq = time.perf_counter()
for i in range(1, N + 1):
    key = f"exam:{SID}:seq:{i}"
    val = f"value-{SID}-{i}"
    r.set(key, val)
end_seq = time.perf_counter()
time_seq_ms = (end_seq - start_seq) * 1000  # 转换为毫秒

# ==================== 2. 方案乙：Pipeline 分批写入计时 ====================
# 计时包括：命令构造、打包、发送，直到收到最后一批回复后停止
start_pipe = time.perf_counter()
pipe = r.pipeline(transaction=False)
batch_counter = 0

for i in range(1, N + 1):
    key = f"exam:{SID}:pipe:{i}"
    val = f"value-{SID}-{i}"
    pipe.set(key, val)
    
    # 达到 100 条或是最后一条时触发提交
    if i % Q == 0 or i == N:
        pipe.execute()
        batch_counter += 1

end_pipe = time.perf_counter()
time_pipe_ms = (end_pipe - start_pipe) * 1000  # 转换为毫秒

# ==================== 3. 结果汇总与填表打印 ====================
print("==================== 测试结果输出表 ====================")
print(f"{'指标':<20} | {'程序输出值'}")
print("-" * 42)
print(f"{'命令总数':<20} | {N}")
print(f"{'Pipeline 批次数':<18} | {total_batches}")
print(f"{'最后一批数量':<18} | {last_batch_size}")
print(f"{'方案甲耗时(ms)':<17} | {time_seq_ms:.2f} ms")
print(f"{'方案乙耗时(ms)':<17} | {time_pipe_ms:.2f} ms")
print("=" * 42)