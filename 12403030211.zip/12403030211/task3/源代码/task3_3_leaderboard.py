from redis.cluster import RedisCluster, ClusterNode
SID = "12403030211"
C = 1
INITIAL_SCORE = 70 + C  # 71 分
MY_MEMBER = f"Student:{SID}"
ZSET_KEY = f"exam:{SID}:leaderboard"

# 1. 连接 Redis 集群（30211端口）
r = RedisCluster(
    startup_nodes=[ClusterNode("127.0.0.1", 30211)],
    decode_responses=True
)

print(f"=== 操作键: {ZSET_KEY} ===\n")

# 测试前清空历史排行榜数据
r.delete(ZSET_KEY)

# 初始排行榜数据字典 {member: score}
init_scores = {
    MY_MEMBER: INITIAL_SCORE,  # 71
    "demo:01": 85,
    "demo:02": 90,
    "demo:03": 60,
    "demo:04": 80
}

# 写入初始成绩
r.zadd(ZSET_KEY, mapping=init_scores)
print(">>> 初始成绩排行榜数据写入成功！")


# 定义辅助打印前 3 名的函数
def print_top_three(title_msg):
    print(title_msg)
    # ZRANGE 带 desc=True 表示从高到低排序，0 到 2 取前 3 名
    top3 = r.zrange(ZSET_KEY, 0, 2, desc=True, withscores=True)
    for index, (member, score) in enumerate(top3, start=1):
        print(f"   第 {index} 名: {member:<24} | 分数: {int(score)}")


# 要求(1)：输出按分数从高到低排列的前 3 名及分数
print("\n================ 要求(1) 初始前 3 名排行榜 ================")
print_top_three("【初始前 3 名】:")

# 要求(2)：将本人分数增加 20 分
print("\n================ 要求(2) 本人分数增加 20 分 ================")
new_score = r.zincrby(ZSET_KEY, 20, MY_MEMBER)
print(f">>> 成功执行 ZINCRBY，本人当前最新分数: {int(new_score)}")

# 要求(3)：再次输出前 3 名及分数
print("\n================ 要求(3) 加分后前 3 名排行榜 ================")
print_top_three("【加分后最新前 3 名】:")

# 要求(4)：查询本人更新后的分数和名次
print("\n================ 要求(4) 查询本人更新后的分数与名次 ================")
my_final_score = int(r.zscore(ZSET_KEY, MY_MEMBER))
# zrevrank 获取降序排名（从 0 开始），+1 转换为常规名次
my_rank_0_based = r.zrevrank(ZSET_KEY, MY_MEMBER)
my_rank = my_rank_0_based + 1

print(f"成员名称: {MY_MEMBER}")
print(f"更新后分数: {my_final_score}")
print(f"更新后名次: 第 {my_rank} 名")