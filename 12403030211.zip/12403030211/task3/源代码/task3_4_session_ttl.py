import time
from redis.cluster import RedisCluster, ClusterNode

SID = "12403030211"
SESSION_KEY = f"exam:{SID}:session"
SESSION_VALUE = f"token_zhangsan_{SID}_LOGIN_SUCCESS"
EXPIRE_SECONDS = 5  # 有效期 5 秒

# 1. 连接 Redis 集群（30211端口）
r = RedisCluster(
    startup_nodes=[ClusterNode("127.0.0.1", 30211)],
    decode_responses=True
)

print(f"=== 操作键: {SESSION_KEY} ===\n")

# 1. 创建个人会话字符串键并设置 5 秒有效期（使用 SET ... EX 5）
r.set(SESSION_KEY, SESSION_VALUE, ex=EXPIRE_SECONDS)

# 要求(1)：创建后立即输出键值和 TTL
val_init = r.get(SESSION_KEY)
ttl_init = r.ttl(SESSION_KEY)
print("================ 要求(1) 创建后立即输出 ================")
print(f"键: {SESSION_KEY}")
print(f"键值: {val_init}")
print(f"剩余生存时间 (TTL): {ttl_init} 秒")

# 要求(2)：等待至少 6 秒
sleep_time = 6
print(f"\n================ 要求(2) 等待 {sleep_time} 秒 ================")
for i in range(sleep_time, 0, -1):
    print(f"倒计时等待中... 还剩 {i} 秒", end="\r", flush=True)
    time.sleep(1)
print(f"已等待完成（共等待 {sleep_time} 秒）！                 ")

# 要求(3)：再次输出键是否存在及 TTL
print("\n================ 要求(3) 等待后再次输出状态 ================")
is_exists = r.exists(SESSION_KEY)  # 1 为存在，0 为不存在
ttl_after = r.ttl(SESSION_KEY)     # 键不存在时 Redis 原生返回 -2
val_after = r.get(SESSION_KEY)

print(f"键是否存在: {'存在 (1)' if is_exists == 1 else '不存在 / 已销毁 (0)'}")
print(f"当前查询键值: {val_after}")
print(f"当前 TTL: {ttl_after} (在 Redis 中，-2 表示键已过期并不存在)")

# 要求(4)：根据结果判断过期验证是否通过
print("\n================ 要求(4) 过期验证结果 ================")
# 判定逻辑：键不存在 (exists=0)、值为空 (None)、TTL 为 -2
if is_exists == 0 and val_after is None and ttl_after == -2:
    print(">>> 【核验通过】：会话在达到 5 秒有效期后成功自动销毁，过期机制验证通过！(PASS)")
else:
    print(">>> 【核验失败】：会话未能按预期自动销毁！(FAIL)")