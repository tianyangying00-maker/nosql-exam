from redis.cluster import RedisCluster, ClusterNode
SID = "12403030211"
PREFIX = f"exam:{SID}:"
key_student = f"{PREFIX}student"
key_chapters = f"{PREFIX}completed_chapters"
key_leaderboard = f"{PREFIX}leaderboard"
key_session = f"{PREFIX}session"
# 连接 Redis 集群
r = RedisCluster(
    startup_nodes=[ClusterNode("127.0.0.1", 30211)],
    decode_responses=True
)

# 确保会话键在有效期内（根据题干要求：会话键应在过期前检查）
r.set(key_session, "token_sample", ex=30)

keys_to_check = [
    ("1. 学生信息维护", key_student, "Hash"),
    ("2. 已完成章节记录", key_chapters, "Set"),
    ("3. 成绩排行榜", key_leaderboard, "Sorted Set"),
    ("4. 会话生命周期", key_session, "String"),
]

print("==================== 四类键的实际数据类型核验 ====================")
for desc, key, expected_structure in keys_to_check:
    actual_type = r.type(key) # 调用 Redis 的 TYPE 命令
    print(f"业务模块: {desc}")
    print(f"  - Redis 键名: {key}")
    print(f"  - 实际数据类型 (TYPE): {actual_type}")
    print(f"  - 核验结果: {'【正确匹配】' if actual_type.lower() in [expected_structure.lower(), 'zset'] else '【类型不符】'}\n")