from redis.cluster import RedisCluster, ClusterNode
SID = "12403030211"
SET_KEY = f"exam:{SID}:completed_chapters"
r = RedisCluster(
    startup_nodes=[ClusterNode("127.0.0.1", 30211)],
    decode_responses=True
)
print(f"=== 操作键: {SET_KEY} ===\n")
r.delete(SET_KEY)

# 依次提交的章节序列
submissions = ["CH01", "CH02", "CH02", "CH03"]

print("================ 要求(1) 依次提交并输出章节数量 ================")
for idx, chapter in enumerate(submissions, start=1):
    # SADD 返回 1 表示新增成功，返回 0 表示元素已存在（未重复添加）
    added = r.sadd(SET_KEY, chapter)
    count = r.scard(SET_KEY) # SCARD 获取集合中元素的总数
    
    status_msg = "新完成章节" if added == 1 else "重复提交(已忽略)"
    print(f"第 {idx} 次提交章节: {chapter:<6} -> 状态: {status_msg} -> 当前已完成章节数量: {count}")

print("\n================ 要求(2) 输出最终全部章节 ================")
all_chapters = r.smembers(SET_KEY) # SMEMBERS 获取全部成员
print(f"最终全部已完成章节列表: {all_chapters}")

print("\n================ 要求(3) 判断 CH02 和 CH04 是否已完成 ================")
# SISMEMBER 判断元素是否在集合中
is_ch02 = bool(r.sismember(SET_KEY, "CH02"))
is_ch04 = bool(r.sismember(SET_KEY, "CH04"))

print(f"章节 CH02 是否已完成: {'【是】(已完成)' if is_ch02 else '【否】(未完成)'}")
print(f"章节 CH04 是否已完成: {'【是】(已完成)' if is_ch04 else '【否】(未完成)'}")

print("\n================ 要求(4) 验证重复提交 CH02 不会增加章节数量 ================")
card_before = r.scard(SET_KEY)
sadd_result = r.sadd(SET_KEY, "CH02") # 再次提交 CH02
card_after = r.scard(SET_KEY)

print(f"再次尝试提交 CH02 前数量: {card_before}")
print(f"SADD 返回值（1为新增成功，0为重复忽略）: {sadd_result}")
print(f"再次尝试提交 CH02 后数量: {card_after}")
if card_before == card_after and sadd_result == 0:
    print(">>> 验证结论: 重复提交 CH02 返回 0 且数量保持不变，成功防重！")