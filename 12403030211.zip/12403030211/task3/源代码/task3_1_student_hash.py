import redis
from redis.cluster import RedisCluster, ClusterNode

SID = "12403030211"
KEY_PREFIX = f"exam:{SID}:"
STUDENT_KEY = f"{KEY_PREFIX}student"

# 1. 连接 Redis Cluster 集群（实验五三主三从环境，端口按实际情况配置，如 7000、7001、6379 等）
try:
    # 尝试以集群模式连接
    r = RedisCluster(
        startup_nodes=[ClusterNode("127.0.0.1", 30211), ClusterNode("127.0.0.1", 7001)],
        decode_responses=True
    )
except Exception:
    # 如果本地测试环境是单机模式，自动降级连接
    r = redis.Redis(host="127.0.0.1", port=6379, decode_responses=True)

print(f"=== 操作键: {STUDENT_KEY} ===\n")

# 先清空该键的历史数据
r.delete(STUDENT_KEY)

# 要求(1)：创建个人信息 Hash
init_data = {
    "studentId": 12403030211,
    "name": "张三",
    "className": "大数据管理与应用2班",  # 可修改为本人真实班级
    "courseId": f"COURSE-{SID}-01",
    "status": "learning"
}
r.hset(STUDENT_KEY, mapping=init_data)
print("1. 初始个人信息 Hash 创建成功：")
print(r.hgetall(STUDENT_KEY))

# 要求(2)：将 status 修改为 completed
r.hset(STUDENT_KEY, "status", "completed")
print("\n2. 已将 status 字段修改为 'completed'")

# 要求(3)：单独读取 name 和 status
name = r.hget(STUDENT_KEY, "name")
status = r.hget(STUDENT_KEY, "status")
print(f"\n3. 单独读取字段：")
print(f"   name: {name}")
print(f"   status: {status}")

# 要求(4)：输出完整 Hash，验证其他字段保留
final_hash = r.hgetall(STUDENT_KEY)
print(f"\n4. 最终完整 Hash 内容（验证 studentId, className, courseId 是否完好保留）：")
for field, value in final_hash.items():
    print(f"   {field}: {value}")